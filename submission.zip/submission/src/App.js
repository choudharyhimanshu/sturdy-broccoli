import { useCallback, useRef, useState } from "react";

import { CARDS } from "./constants";
import CardView from "./CardView";
import { randomNumber } from "./utils";

import "./App.css";
import "bootstrap/dist/css/bootstrap.css";

const RANDOM_CARDS_SIZE = 5;
const TOTAL_CARDS = 52;

function App() {
  const availableCards = useRef([...CARDS]);
  const [openCards, setOpenCards] = useState([]);

  const handleDrawCardsAction = useCallback(() => {
    const newRandomCards = [];
    for (
      let i = 0;
      i < RANDOM_CARDS_SIZE && availableCards.current.length > 0;
      i++
    ) {
      const randomIndex = randomNumber(0, availableCards.current.length - 1);
      newRandomCards.push(availableCards.current.splice(randomIndex, 1)[0]);
    }
    setOpenCards(openCards.concat(newRandomCards));
  }, [openCards]);

  const handleResetAction = useCallback(() => {
    availableCards.current = [...CARDS];
    setOpenCards([]);
  }, []);

  return (
    <div className="container py-5">
      <div className="row row-cols-2 row-cols-xs-2 row-cols-sm-2 row-cols-md-3 row-cols-lg-5 g-5">
        {openCards.map((card) => (
          <CardView
            key={`${card.suit}_${card.number}`}
            suite={card.suit}
            number={card.number}
          />
        ))}
      </div>
      <div className="row py-5">
        <div className="col d-grid gap-2">
          <button
            className="btn btn-lg btn-primary"
            onClick={handleDrawCardsAction}
            disabled={openCards.length === TOTAL_CARDS}
          >
            Draw 5 cards
          </button>
          <button
            className="btn btn-lg btn-secondary"
            onClick={handleResetAction}
          >
            Reset
          </button>
          <button className="btn btn-light" disabled>
            Open: {openCards.length} | Available:{" "}
            {TOTAL_CARDS - openCards.length}
          </button>
        </div>
      </div>
    </div>
  );
}

export default App;
