import ClubImg from "./assets/img/Club.png";
import HeartImg from "./assets/img/Heart.png";
import DiamondImg from "./assets/img/Diamond.png";
import SpadeImg from "./assets/img/Spade.png";

function getSuiteImage(suite) {
  switch (suite) {
    case "S":
      return SpadeImg;
    case "H":
      return HeartImg;
    case "D":
      return DiamondImg;
    case "C":
      return ClubImg;
    default:
      throw Error("Invalid suite type");
  }
}

function CardView({ suite, number }) {
  return (
    <div className="col">
      <div className="card px-3 h-100">
        <div className="card-body">
          <h5 className="card-title fs-4">{number}</h5>
        </div>

        <img
          src={getSuiteImage(suite)}
          className="custom-card-image"
          alt={suite}
        />
        <div className="card-body">
          <h5 className="card-title text-end fs-4">{number}</h5>
        </div>
      </div>
    </div>
  );
}

export default CardView;
