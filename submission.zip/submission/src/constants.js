const suits = ["S", "H", "D", "C"];
const numbers = [
  "2",
  "3",
  "4",
  "5",
  "6",
  "7",
  "8",
  "9",
  "10",
  "J",
  "Q",
  "K",
  "A",
];

export const CARDS = [];
suits.forEach(suit => {
  numbers.forEach(number => {
    CARDS.push({suit, number});
  });
});
