
function Header() {
    return <div>
        <h5><i className="bi bi-arrow-left-short mr-2" /> Make payment</h5>
    </div>;
}

export default Header;
