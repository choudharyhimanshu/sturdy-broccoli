import React from "react";

import Header from "./Header";
import PaymentOptions from "./PaymentOptions";
import PaymentMethods from "./PaymentMethods";

import "./sass/custom-bootstrap.scss";
import "./sass/app.scss";

function App() {
  const [selectedPaymentAmount, setSelectedPaymentAmount] =
    React.useState(false);

  return (
    <div className="container py-5">
      <div className="row">
        <div className="col-12">
          <Header />
        </div>
      </div>
      <div className="row">
        <div className="col-12 py-5">
          <PaymentOptions
            onChange={(amount) => setSelectedPaymentAmount(amount)}
          />
        </div>
      </div>
      <div className="row">
        <div className="col-12">
          {selectedPaymentAmount && <PaymentMethods />}
        </div>
      </div>
    </div>
  );
}

export default App;
