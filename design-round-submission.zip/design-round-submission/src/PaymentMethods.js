import phonepeLogo from "./assets/svg/phonepe.svg";
import bhimLogo from "./assets/svg/bhim.svg";
import paytmLogo from "./assets/svg/paytm.svg";
import gpayLogo from "./assets/svg/gpay.svg";

const UPI_OPTIONS = [
  { key: "phonepe", logo: phonepeLogo, label: "PhonePe" },
  { key: "bhim", logo: bhimLogo, label: "Bhim" },
  { key: "paytm", logo: paytmLogo, label: "Paytm" },
  { key: "gpay", logo: gpayLogo, label: "GooglePay" },
];

function UPICard({ upiOption }) {
  return (
    <div className="col text-center">
      <div className="py-3 shadow-sm upi-card">
        <img src={upiOption.logo} alt={upiOption.key} />
      </div>
      <p className="m-0 mt-2 small text-muted">{upiOption.label}</p>
    </div>
  );
}

function BankAccountDetails() {
  return (
    <div className="p-3" style={{ backgroundColor: "#FAFAFA" }}>
      <h6 className="mb-3">
        John Doe <span className="text-muted small float-end">Axis Bank</span>
      </h6>
      <div>
        <p className="text-muted small mb-2">Account Number</p>
        <p>123464859908XFGUJ</p>
      </div>
      <div>
        <p className="text-muted small mb-2">IFSC Code</p>
        <p className="mb-0">UTIXFRD</p>
      </div>
    </div>
  );
}

function PaymentMethods() {
  return (
    <div>
      <div className="row">
        <div className="col">
          <h6 className="text-muted">Choose a payment method</h6>
        </div>
      </div>
      <div className="row">
        <div className="col py-3">
          <h6 className="text-muted">UPI</h6>
        </div>
      </div>
      <div className="row align-items-start">
        {UPI_OPTIONS.map((upiOption) => (
          <UPICard key={upiOption.key} upiOption={upiOption} />
        ))}
      </div>
      <div className="row">
        <div className="col py-5">
          <h6 className="text-muted mb-3">Deposit money in account</h6>
          <BankAccountDetails />
        </div>
      </div>
    </div>
  );
}

export default PaymentMethods;
