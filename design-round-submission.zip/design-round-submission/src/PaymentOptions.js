import React from "react";

import CustomAmountCard from "./CustomAmountCard";
import { formatAmount } from "./utils";

export const DEFAULT_TOTAL_DUE_AMOUNT = 10000;

function TotalAmountCard({ isSelected, onClick }) {
  return (
    <div className="card" onClick={onClick}>
      <div className="card-body">
        <div className="row align-items-center">
          <div className="col">
            <h6 className="text-muted">Pay total due amount</h6>
            <h6 className={isSelected ? 'fw-bold' : ''}>Rs. {formatAmount(DEFAULT_TOTAL_DUE_AMOUNT)}</h6>
          </div>
          <div className="col-auto">
            <input
              class="form-check-input"
              type="radio"
              checked={isSelected}
            ></input>
          </div>
        </div>
      </div>
    </div>
  );
}

const EPaymentOption = {
  totalDue: "totalDue",
  customAmount: "customAmount",
};

function PaymentOptions({ onChange }) {
  const [selectedOption, setSelectedOption] = React.useState();

  React.useEffect(() => {
    onChange(selectedOption && true);
  }, [selectedOption]);

  return (
    <div>
      <TotalAmountCard
        isSelected={selectedOption === EPaymentOption.totalDue}
        onClick={() => setSelectedOption(EPaymentOption.totalDue)}
      />
      <CustomAmountCard
        isSelected={selectedOption === EPaymentOption.customAmount}
        onClick={() => setSelectedOption(EPaymentOption.customAmount)}
      />
    </div>
  );
}

export default PaymentOptions;
