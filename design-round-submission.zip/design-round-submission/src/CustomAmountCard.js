import React from "react";
import { Offcanvas, OffcanvasBody } from "reactstrap";
import { DEFAULT_TOTAL_DUE_AMOUNT } from "./PaymentOptions";
import { formatAmount } from "./utils";

function CustomAmountCard({ isSelected, onClick }) {
  const [isCanvasOpen, setIsCanvasOpen] = React.useState(false);
  const [isCustomAmount, setIsCustomAmount] = React.useState(false);
  const [amount, setAmount] = React.useState(DEFAULT_TOTAL_DUE_AMOUNT);

  const handleSelectAction = React.useCallback(() => {
    setIsCanvasOpen(true);
  }, []);

  const handleAmountSubmit = React.useCallback(() => {
    setIsCanvasOpen(false);
    setIsCustomAmount(true);
    onClick();
  }, [onClick]);

  return (
    <div>
      <div className="card mt-3" onClick={handleSelectAction}>
        <div className="card-body py-4">
          <div className="row align-items-center">
            <div className="col">
              <h6
                className={`mb-0 ${
                  isCustomAmount ? "text-muted" : "text-secondary"
                }`}
              >
                Pay custom amount
              </h6>
              {isCustomAmount && (
                <h6 className={isSelected ? "fw-bold mt-2" : "mt-2"}>
                  Rs. {formatAmount(amount)}
                </h6>
              )}
            </div>
            <div className="col-auto">
              {isCustomAmount ? (
                <button
                  className="btn btn-light px-4 border-0 text-secondary rounded-pill"
                  onClick={handleSelectAction}
                  style={{ backgroundColor: "rgba(194, 196, 251, .2)" }}
                >
                  Edit
                </button>
              ) : (
                <input
                  class="form-check-input"
                  type="radio"
                  checked={isSelected}
                />
              )}
            </div>
          </div>
        </div>
      </div>
      <Offcanvas isOpen={isCanvasOpen} direction="bottom">
        <OffcanvasBody>
          <h6 className="text-muted mb-4">Pay custom amount</h6>
          <div className="mb-4">
            {/* <input
              class="form-control form-control-lg"
              type="text"
              value={amount}
              onChange={(event) => setAmount(Number(event.target.value))}
            /> */}
            <div class="input-group mb-3">
              <span class="input-group-text bg-transparent border-0 fs-4">
                Rs.
              </span>
              <input
                type="number"
                class="form-control form-control-lg border-0"
                value={amount}
                onChange={(event) => setAmount(Number(event.target.value))}
              />
            </div>
          </div>
          <button
            className="btn btn-primary btn-lg mb-3 rounded-pill w-100"
            onClick={handleAmountSubmit}
          >
            Proceed
          </button>
        </OffcanvasBody>
      </Offcanvas>
    </div>
  );
}

export default CustomAmountCard;
